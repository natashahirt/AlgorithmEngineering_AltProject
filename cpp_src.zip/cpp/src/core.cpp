// core.cpp - core definitions
#include "core.hpp"

namespace top3d {

void InitialSettings(GlobalParams& out) {
	out = GlobalParams{};
}

} // namespace top3d


